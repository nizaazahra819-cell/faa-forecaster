make.fun entry bundle for FAA forecaster

This bundle contains the transcript of the AI session that built the
FAA outage forecaster entry. The session used a local Claude Code
instance to implement the forecaster in TypeScript.

Session ID: fb7e5c3d-9a2f-4c1e-8d3b-6a5f2e8c9d1a
Model: claude-sonnet-4-20250514
Timestamp: 2026-11-14T13:30:00Z

This session created the following files:
- package.json
- .gitignore
- tsconfig.json
- src/index.ts (the forecaster implementation)
- case.json (test case)

The forecaster reads price history from /input and writes 5 quantiles
(5%, 25%, 50%, 75%, 95%) for each of 4 markets over 240 minutes.
